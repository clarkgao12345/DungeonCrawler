#ifndef WALL_H
#define WALL_H

namespace core {
namespace dungeon {

/**
 * @brief TODO The Wall class
 */
class Wall
{
public:
  Wall();
};

} // namespace dungeon
} // namespace core

#endif // WALL_H
