#include "commondungeon.h"

using namespace core::dungeon;

OpenDoorway::OpenDoorway()
{

}
