#ifndef DOOR_H
#define DOOR_H

namespace core {
namespace dungeon {

/**
 * @brief TODO The Door class
 */
class Door
{
public:
  Door();
};

} // namespace dungeon
} // namespace core

#endif // DOOR_H
