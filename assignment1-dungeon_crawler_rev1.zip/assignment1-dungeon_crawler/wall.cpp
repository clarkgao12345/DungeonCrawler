#include "wall.h"

using namespace core::dungeon;

Wall::Wall()
{

}
