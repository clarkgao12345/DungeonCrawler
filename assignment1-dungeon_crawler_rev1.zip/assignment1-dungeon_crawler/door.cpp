#include "door.h"

using namespace core::dungeon;

Door::Door()
{

}
